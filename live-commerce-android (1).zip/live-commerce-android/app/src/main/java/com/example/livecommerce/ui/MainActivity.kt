package com.example.livecommerce.ui

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.livecommerce.ui.theme.LiveCommerceTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LiveCommerceTheme {
                MainScreen(
                    onJoinLiveRoom = { roomName, userName ->
                        navigateToLiveStream(roomName, userName)
                    }
                )
            }
        }
    }

    private fun navigateToLiveStream(roomName: String, userName: String) {
        val intent = Intent(this, LiveStreamActivity::class.java).apply {
            putExtra("roomName", roomName)
            putExtra("userName", userName)
        }
        startActivity(intent)
    }
}

@Composable
fun MainScreen(onJoinLiveRoom: (String, String) -> Unit) {
    var roomName by remember { mutableStateOf("") }
    var userName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Logo/Title
        Text(
            text = "Live Commerce",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Text(
            text = "Shop, Sell & Connect in Real Time",
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 48.dp)
        )

        // Room Name Input
        OutlinedTextField(
            value = roomName,
            onValueChange = { roomName = it },
            label = { Text("Room Name") },
            placeholder = { Text("e.g., fashion-show-2026") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            singleLine = true
        )

        // User Name Input
        OutlinedTextField(
            value = userName,
            onValueChange = { userName = it },
            label = { Text("Your Name") },
            placeholder = { Text("Enter your name") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 32.dp),
            singleLine = true
        )

        // Join Button
        Button(
            onClick = {
                if (roomName.isNotBlank() && userName.isNotBlank()) {
                    onJoinLiveRoom(roomName, userName)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            enabled = roomName.isNotBlank() && userName.isNotBlank()
        ) {
            Text("Join Live Room", fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Info Text
        Text(
            text = "Use unique room names for each live session",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 24.dp)
        )
    }
}
