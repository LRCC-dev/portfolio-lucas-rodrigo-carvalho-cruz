package com.example.livecommerce.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.livecommerce.ui.theme.LiveCommerceTheme
import dagger.hilt.android.AndroidEntryPoint
import org.jitsi.meet.sdk.JitsiMeetActivity
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions
import org.jitsi.meet.sdk.JitsiMeetView
import java.net.URL

@AndroidEntryPoint
class LiveStreamActivity : ComponentActivity() {
    private var jitsiMeetView: JitsiMeetView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val roomName = intent.getStringExtra("roomName") ?: "default-room"
        val userName = intent.getStringExtra("userName") ?: "Anonymous"

        setContent {
            LiveCommerceTheme {
                LiveStreamScreen(
                    roomName = roomName,
                    userName = userName,
                    onJitsiViewCreated = { view ->
                        jitsiMeetView = view
                        initializeJitsi(view, roomName, userName)
                    }
                )
            }
        }
    }

    private fun initializeJitsi(view: JitsiMeetView, roomName: String, userName: String) {
        val options = JitsiMeetConferenceOptions.Builder()
            .setServerURL(URL("https://meet.jitsi.example.com"))
            .setRoom(roomName)
            .setFeatureFlag("toolbox.enabled", true)
            .setFeatureFlag("filmstrip.enabled", false)
            .setFeatureFlag("welcomepage.enabled", false)
            .setFeatureFlag("add-people.enabled", false)
            .setFeatureFlag("invite.enabled", false)
            .build()

        JitsiMeetActivity.launch(this, options)
    }

    override fun onDestroy() {
        jitsiMeetView?.dispose()
        jitsiMeetView = null
        super.onDestroy()
    }
}

@Composable
fun LiveStreamScreen(
    roomName: String,
    userName: String,
    onJitsiViewCreated: (JitsiMeetView) -> Unit
) {
    var showChat by remember { mutableStateOf(false) }
    var showProducts by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Jitsi Meet View (placeholder)
        AndroidView(
            factory = { context ->
                JitsiMeetView(context).apply {
                    onJitsiViewCreated(this)
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        // Overlay: Products Panel
        if (showProducts) {
            ProductsPanel(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(16.dp)
                    .width(280.dp)
            )
        }

        // Overlay: Chat Panel
        if (showChat) {
            ChatPanel(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(16.dp)
                    .width(280.dp)
            )
        }

        // Control Buttons
        Row(
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FloatingActionButton(
                onClick = { showChat = !showChat },
                modifier = Modifier.size(48.dp),
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Text("💬")
            }

            FloatingActionButton(
                onClick = { showProducts = !showProducts },
                modifier = Modifier.size(48.dp),
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Text("🛍️")
            }
        }
    }
}

@Composable
fun ProductsPanel(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .heightIn(min = 200.dp, max = 400.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Featured Products",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Product cards will appear here",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun ChatPanel(modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .heightIn(min = 200.dp, max = 400.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "Live Chat",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "Chat messages will appear here",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
