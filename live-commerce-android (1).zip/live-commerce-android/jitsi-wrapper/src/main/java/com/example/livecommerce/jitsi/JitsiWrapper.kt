package com.example.livecommerce.jitsi

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.livecommerce.domain.model.ConferenceEvent
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.receiveAsFlow
import org.jitsi.meet.sdk.BroadcastAction
import org.jitsi.meet.sdk.BroadcastEvent
import org.jitsi.meet.sdk.JitsiMeet
import org.jitsi.meet.sdk.JitsiMeetConferenceOptions
import java.net.URL

/**
 * JitsiWrapper é uma camada de abstração em torno do Jitsi Meet SDK.
 * Fornece uma interface limpa e reativa para o restante da aplicação.
 */
class JitsiWrapper(private val context: Context) {

    private val conferenceEventChannel = Channel<ConferenceEvent>(Channel.BUFFERED)
    private val broadcastReceiver = JitsiBroadcastReceiver { event ->
        conferenceEventChannel.trySend(event)
    }

    /**
     * Inicializa o Jitsi Meet SDK com opções padrão.
     */
    fun initialize(serverUrl: String = "https://meet.jitsi.example.com") {
        val defaultOptions = JitsiMeetConferenceOptions.Builder()
            .setServerURL(URL(serverUrl))
            .setFeatureFlag("toolbox.enabled", true)
            .setFeatureFlag("filmstrip.enabled", false)
            .setFeatureFlag("welcomepage.enabled", false)
            .setFeatureFlag("add-people.enabled", false)
            .setFeatureFlag("invite.enabled", false)
            .build()

        JitsiMeet.setDefaultConferenceOptions(defaultOptions)
    }

    /**
     * Registra listeners para eventos da conferência.
     */
    fun startListening() {
        val intentFilter = IntentFilter().apply {
            addAction(BroadcastEvent.Type.CONFERENCE_JOINED.getAction())
            addAction(BroadcastEvent.Type.CONFERENCE_TERMINATED.getAction())
            addAction(BroadcastEvent.Type.CONFERENCE_WILL_JOIN.getAction())
            addAction(BroadcastEvent.Type.PARTICIPANT_JOINED.getAction())
            addAction(BroadcastEvent.Type.PARTICIPANT_LEFT.getAction())
            addAction(BroadcastEvent.Type.ENDPOINT_TEXT_MESSAGE_RECEIVED.getAction())
            addAction(BroadcastEvent.Type.SCREEN_SHARE_TOGGLED.getAction())
            addAction(BroadcastEvent.Type.AUDIO_MUTED_CHANGED.getAction())
            addAction(BroadcastEvent.Type.VIDEO_MUTED_CHANGED.getAction())
        }

        LocalBroadcastManager.getInstance(context)
            .registerReceiver(broadcastReceiver, intentFilter)
    }

    /**
     * Para de escutar eventos da conferência.
     */
    fun stopListening() {
        try {
            LocalBroadcastManager.getInstance(context)
                .unregisterReceiver(broadcastReceiver)
        } catch (e: IllegalArgumentException) {
            // Receiver não estava registrado
        }
    }

    /**
     * Retorna um Flow de eventos da conferência.
     */
    fun observeConferenceEvents(): Flow<ConferenceEvent> {
        return conferenceEventChannel.receiveAsFlow()
    }

    /**
     * Envia uma ação de broadcast para o Jitsi.
     */
    fun sendBroadcastAction(action: BroadcastAction.Type, data: Map<String, Any> = emptyMap()) {
        val intent = Intent(action.getAction()).apply {
            data.forEach { (key, value) ->
                when (value) {
                    is String -> putExtra(key, value)
                    is Boolean -> putExtra(key, value)
                    is Int -> putExtra(key, value)
                    else -> putExtra(key, value.toString())
                }
            }
        }
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent)
    }

    /**
     * Muta/desmuta o áudio.
     */
    fun setAudioMuted(muted: Boolean) {
        sendBroadcastAction(BroadcastAction.Type.SET_AUDIO_MUTED, mapOf("muted" to muted))
    }

    /**
     * Muta/desmuta o vídeo.
     */
    fun setVideoMuted(muted: Boolean) {
        sendBroadcastAction(BroadcastAction.Type.SET_VIDEO_MUTED, mapOf("muted" to muted))
    }

    /**
     * Sai da conferência.
     */
    fun hangUp() {
        sendBroadcastAction(BroadcastAction.Type.HANG_UP)
    }

    /**
     * Envia uma mensagem de chat.
     */
    fun sendChatMessage(message: String, to: String? = null) {
        val data = mutableMapOf("message" to message)
        if (to != null) {
            data["to"] = to
        }
        sendBroadcastAction(BroadcastAction.Type.SEND_CHAT_MESSAGE, data)
    }

    /**
     * Ativa/desativa compartilhamento de tela.
     */
    fun toggleScreenShare(enabled: Boolean) {
        sendBroadcastAction(BroadcastAction.Type.TOGGLE_SCREEN_SHARE, mapOf("enabled" to enabled))
    }

    /**
     * Abre o chat.
     */
    fun openChat(participantId: String? = null) {
        val data = if (participantId != null) {
            mapOf("to" to participantId)
        } else {
            emptyMap()
        }
        sendBroadcastAction(BroadcastAction.Type.OPEN_CHAT, data)
    }

    /**
     * Fecha o chat.
     */
    fun closeChat() {
        sendBroadcastAction(BroadcastAction.Type.CLOSE_CHAT)
    }

    /**
     * Libera recursos.
     */
    fun dispose() {
        stopListening()
        conferenceEventChannel.close()
    }
}
