package com.example.livecommerce.jitsi

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.livecommerce.domain.model.ConferenceEvent
import com.example.livecommerce.domain.model.ChatMessage
import com.example.livecommerce.domain.model.Participant
import com.example.livecommerce.domain.model.UserRole
import org.jitsi.meet.sdk.BroadcastEvent

/**
 * BroadcastReceiver que escuta eventos do Jitsi Meet SDK
 * e os converte em eventos de domínio.
 */
class JitsiBroadcastReceiver(
    private val onEventReceived: (ConferenceEvent) -> Unit
) : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {
        if (intent == null) return

        val action = intent.action ?: return
        val data = intent.extras ?: return

        val event = when (action) {
            BroadcastEvent.Type.CONFERENCE_JOINED.getAction() -> {
                val url = data.getString("url") ?: ""
                val sessionId = extractSessionId(url)
                ConferenceEvent.ConferenceJoined(sessionId, url)
            }

            BroadcastEvent.Type.CONFERENCE_TERMINATED.getAction() -> {
                val url = data.getString("url") ?: ""
                val error = data.getString("error")
                val sessionId = extractSessionId(url)
                ConferenceEvent.ConferenceTerminated(sessionId, error)
            }

            BroadcastEvent.Type.CONFERENCE_WILL_JOIN.getAction() -> {
                val url = data.getString("url") ?: ""
                val sessionId = extractSessionId(url)
                ConferenceEvent.ConferenceWillJoin(sessionId, url)
            }

            BroadcastEvent.Type.PARTICIPANT_JOINED.getAction() -> {
                val participantId = data.getString("participantId") ?: ""
                val name = data.getString("name") ?: "Anonymous"
                val role = when (data.getString("role")) {
                    "moderator" -> UserRole.PRESENTER
                    else -> UserRole.VIEWER
                }
                val participant = Participant(participantId, name, role)
                ConferenceEvent.ParticipantJoined(participant)
            }

            BroadcastEvent.Type.PARTICIPANT_LEFT.getAction() -> {
                val participantId = data.getString("participantId") ?: ""
                ConferenceEvent.ParticipantLeft(participantId)
            }

            BroadcastEvent.Type.ENDPOINT_TEXT_MESSAGE_RECEIVED.getAction() -> {
                val senderId = data.getString("senderId") ?: ""
                val message = data.getString("message") ?: ""
                val chatMessage = ChatMessage(
                    id = System.currentTimeMillis().toString(),
                    senderId = senderId,
                    senderName = "User",
                    content = message,
                    liveSessionId = ""
                )
                ConferenceEvent.MessageReceived(chatMessage)
            }

            BroadcastEvent.Type.SCREEN_SHARE_TOGGLED.getAction() -> {
                val participantId = data.getString("participantId") ?: ""
                val sharing = data.getBoolean("sharing", false)
                ConferenceEvent.ScreenShareToggled(participantId, sharing)
            }

            BroadcastEvent.Type.AUDIO_MUTED_CHANGED.getAction() -> {
                val muted = data.getBoolean("muted", false)
                ConferenceEvent.AudioMutedChanged(muted)
            }

            BroadcastEvent.Type.VIDEO_MUTED_CHANGED.getAction() -> {
                val muted = data.getBoolean("muted", false)
                ConferenceEvent.VideoMutedChanged(muted)
            }

            else -> return
        }

        onEventReceived(event)
    }

    private fun extractSessionId(url: String): String {
        return url.substringAfterLast("/").takeIf { it.isNotEmpty() } ?: "default"
    }
}
