package com.example.livecommerce.domain.model

import java.io.Serializable

// Enums
enum class UserRole {
    PRESENTER, VIEWER
}

enum class LiveStatus {
    SCHEDULED, LIVE, ENDED
}

enum class OrderStatus {
    PENDING, CONFIRMED, SHIPPED, DELIVERED, CANCELLED
}

// User
data class User(
    val id: String,
    val name: String,
    val email: String,
    val role: UserRole = UserRole.VIEWER,
    val profileImage: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) : Serializable

// Live Session
data class LiveSession(
    val id: String,
    val title: String,
    val description: String,
    val presenterId: String,
    val presenterName: String,
    val startTime: Long,
    val endTime: Long? = null,
    val status: LiveStatus = LiveStatus.SCHEDULED,
    val participantCount: Int = 0,
    val thumbnailUrl: String? = null
) : Serializable

// Product
data class Product(
    val id: String,
    val name: String,
    val description: String,
    val price: Double,
    val image: String,
    val stock: Int,
    val liveSessionId: String,
    val category: String? = null,
    val rating: Float = 0f
) : Serializable

// Chat Message
data class ChatMessage(
    val id: String,
    val senderId: String,
    val senderName: String,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val liveSessionId: String,
    val isSystemMessage: Boolean = false
) : Serializable

// Order
data class Order(
    val id: String,
    val userId: String,
    val liveSessionId: String,
    val products: List<OrderItem>,
    val totalPrice: Double,
    val status: OrderStatus = OrderStatus.PENDING,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) : Serializable

// Order Item
data class OrderItem(
    val productId: String,
    val productName: String,
    val quantity: Int,
    val unitPrice: Double,
    val totalPrice: Double
) : Serializable

// Reaction
data class Reaction(
    val id: String,
    val userId: String,
    val emoji: String,
    val timestamp: Long = System.currentTimeMillis(),
    val liveSessionId: String
) : Serializable

// Participant
data class Participant(
    val id: String,
    val name: String,
    val role: UserRole,
    val joinedAt: Long = System.currentTimeMillis()
) : Serializable

// Conference Event
sealed class ConferenceEvent {
    data class ConferenceJoined(val sessionId: String, val url: String) : ConferenceEvent()
    data class ConferenceTerminated(val sessionId: String, val error: String? = null) : ConferenceEvent()
    data class ConferenceWillJoin(val sessionId: String, val url: String) : ConferenceEvent()
    data class ParticipantJoined(val participant: Participant) : ConferenceEvent()
    data class ParticipantLeft(val participantId: String) : ConferenceEvent()
    data class MessageReceived(val message: ChatMessage) : ConferenceEvent()
    data class ScreenShareToggled(val participantId: String, val sharing: Boolean) : ConferenceEvent()
    data class AudioMutedChanged(val muted: Boolean) : ConferenceEvent()
    data class VideoMutedChanged(val muted: Boolean) : ConferenceEvent()
}

// Result Wrapper
sealed class Result<out T> {
    data class Success<T>(val data: T) : Result<T>()
    data class Error(val exception: Exception) : Result<Nothing>()
    object Loading : Result<Nothing>()
}
