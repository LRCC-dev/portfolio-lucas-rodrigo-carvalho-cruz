package com.example.livecommerce.domain.repository

import com.example.livecommerce.domain.model.*
import kotlinx.coroutines.flow.Flow

interface LiveSessionRepository {
    suspend fun joinLiveSession(roomName: String, userName: String): Result<LiveSession>
    suspend fun leaveLiveSession(sessionId: String): Result<Unit>
    suspend fun getLiveSession(sessionId: String): Result<LiveSession>
    fun observeLiveSession(sessionId: String): Flow<LiveSession>
}

interface ChatRepository {
    suspend fun sendMessage(message: ChatMessage): Result<ChatMessage>
    suspend fun getMessages(sessionId: String, limit: Int = 50): Result<List<ChatMessage>>
    fun observeMessages(sessionId: String): Flow<ChatMessage>
}

interface ProductRepository {
    suspend fun getProducts(sessionId: String): Result<List<Product>>
    suspend fun getProduct(productId: String): Result<Product>
    fun observeProducts(sessionId: String): Flow<List<Product>>
}

interface OrderRepository {
    suspend fun createOrder(order: Order): Result<Order>
    suspend fun getOrderHistory(userId: String): Result<List<Order>>
    suspend fun getOrder(orderId: String): Result<Order>
    fun observeOrderHistory(userId: String): Flow<List<Order>>
}

interface ReactionRepository {
    suspend fun sendReaction(reaction: Reaction): Result<Reaction>
    fun observeReactions(sessionId: String): Flow<Reaction>
}

interface ParticipantRepository {
    suspend fun getParticipants(sessionId: String): Result<List<Participant>>
    fun observeParticipants(sessionId: String): Flow<List<Participant>>
}

interface UserRepository {
    suspend fun getCurrentUser(): Result<User>
    suspend fun updateUser(user: User): Result<User>
    suspend fun logout(): Result<Unit>
}

interface ConferenceRepository {
    fun observeConferenceEvents(): Flow<ConferenceEvent>
    suspend fun sendBroadcastAction(action: String, data: Map<String, Any>): Result<Unit>
}
