# 🛍️ Live Commerce

**Shop, Sell & Connect in Real Time**

Um aplicativo Android nativo que revoluciona o e-commerce ao vivo, integrando o Jitsi Meet SDK com uma interface customizada para interações comerciais em tempo real. Transmita produtos, interaja com espectadores e realize vendas tudo em uma única experiência imersiva.

---

## 💡 Proposta de Valor

O **Live Commerce** resolve um problema crítico no e-commerce moderno: a falta de conexão entre transmissões de vídeo e compras. Enquanto plataformas tradicionais oferecem apenas vídeo ou apenas compras, o Live Commerce integra ambas de forma perfeita.

### Por que Live Commerce é Único?

| Aspecto | Solução Tradicional | Live Commerce |
|--------|-------------------|---------------|
| **Transmissão** | Apenas vídeo | Vídeo + Comércio Integrado |
| **Interação** | Chat simples | Chat + Reações em Tempo Real |
| **Compra** | Sair da transmissão | Comprar sem sair da live |
| **Controle** | Limitado | Feature flags customizáveis |
| **Arquitetura** | Monolítica | Clean Architecture modular |

---

## 📱 Capturas de Tela

### Tela de Entrada
```
┌─────────────────────────────┐
│                             │
│    Live Commerce            │
│  Shop, Sell & Connect       │
│                             │
│  ┌─────────────────────┐    │
│  │ Room Name           │    │
│  │ fashion-show-2026   │    │
│  └─────────────────────┘    │
│                             │
│  ┌─────────────────────┐    │
│  │ Your Name           │    │
│  │ Enter your name...  │    │
│  └─────────────────────┘    │
│                             │
│  ┌─────────────────────┐    │
│  │  Join Live Room  →  │    │
│  └─────────────────────┘    │
│                             │
└─────────────────────────────┘
```

### Tela de Transmissão
```
┌─────────────────────────────┐
│  Live Room: "Fashion Show"  │
├─────────────────────────────┤
│                             │
│   📹 Video Stream           │
│   (Jitsi Meet)              │
│                             │
│  ┌──────────────┐ ┌──────┐ │
│  │ Chat & Reações│ │💬 🛍️│ │
│  │ Messages here │ └──────┘ │
│  │               │          │
│  │ João: Que    │          │
│  │ produto lindo│          │
│  │               │          │
│  │ Maria: Quero!│          │
│  └──────────────┘          │
│                             │
│  ┌──────────────────────┐   │
│  │ Featured Products    │   │
│  │ - Product 1: $99.99  │   │
│  │ - Product 2: $149.99 │   │
│  └──────────────────────┘   │
└─────────────────────────────┘
```

---

## 🎬 Demonstração em Vídeo

[Vídeo de demonstração será inserido aqui]

---

## 📋 Instruções de Uso

### 🔧 Instalação

#### Via APK (Mais Rápido)

```bash
# Baixe o APK mais recente
# https://github.com/LRCC-dev/live-commerce-app/releases

# Instale no seu dispositivo Android
adb install live-commerce-app-release.apk
```

#### Via Emulador Android

```bash
# Clone o repositório
git clone https://github.com/LRCC-dev/live-commerce-app.git
cd live-commerce-app

# Abra no Android Studio
# File → Open → Selecione a pasta

# Aguarde Gradle sincronizar

# Execute (Shift + F10)
# Ou compile APK: ./gradlew assembleDebug
```

### ✅ Primeira Execução

1. Abra o aplicativo Live Commerce
2. Toque no ícone do Live Commerce na tela inicial
3. Digite o nome da sala (ex: `fashion-show-2026`)
4. Digite seu nome de usuário
5. Toque em "Join Live Room"
6. Aguarde a conexão com o servidor Jitsi

### 📺 Durante a Transmissão

| Ação | Como Fazer |
|------|-----------|
| Mutar/Desmutar Áudio | Toque no ícone 🔇 |
| Câmera On/Off | Toque no ícone 📹 |
| Enviar Mensagem | Digite no chat e pressione enviar |
| Reagir com Emoji | Toque em 😂 para reações rápidas |
| Compartilhar Tela | Toque em 📺 (se disponível) |
| Mute Volume | Toque no ícone 🔊 |
| Sair da Live | Toque em ✕ ou volte |

### 🛒 Gerenciar Produtos (Futura Integração)

[Seção será adicionada quando integração de produtos estiver pronta]

---

## 👁️ Preview & QR Code

### Escanele para Acessar

Abra a câmera do seu telefone e aponte para o QR Code abaixo:

```
┌──────────────────────────────┐
│                              │
│  QR CODE - LIVE COMMERCE     │
│                              │
│  [QR Code será inserido aqui]│
│                              │
│  Resolução: 1248x1248px      │
│  Link: GitHub Releases       │
│                              │
│  ✓ Leva direto para o repo   │
│  ✓ Acesso ao APK mais recente│
│  ✓ Documentação completa     │
│                              │
└──────────────────────────────┘
```

### Links Diretos

- **Repositório GitHub:** https://github.com/LRCC-dev/live-commerce-app
- **Releases & APK:** https://github.com/LRCC-dev/live-commerce-app/releases
- **Issues & Feedback:** https://github.com/LRCC-dev/live-commerce-app/issues
- **Documentação Completa:** [SETUP_EMULATOR.md](SETUP_EMULATOR.md)

---

## 🏗️ Arquitetura Técnica

O Live Commerce segue o padrão **Clean Architecture** com 5 camadas bem definidas:

```
┌──────────────────────────────────────────┐
│  UI Layer (Jetpack Compose)              │
│  MainActivity | LiveStreamActivity       │
└──────────────────────────────────────────┘
                    ↓
┌──────────────────────────────────────────┐
│  Domain Layer (Business Logic)           │
│  Use Cases | Entities | Repositories    │
└──────────────────────────────────────────┘
                    ↓
┌──────────────────────────────────────────┐
│  Data Layer (Data Management)            │
│  Repository Implementations | APIs       │
└──────────────────────────────────────────┘
                    ↓
┌──────────────────────────────────────────┐
│  Jitsi Wrapper (SDK Abstraction)         │
│  SDK Integration | Event Management      │
└──────────────────────────────────────────┘
```

### Módulos do Projeto

| Módulo | Responsabilidade |
|--------|-----------------|
| `:app` | Camada de apresentação, Activities, UI |
| `:domain` | Lógica de negócio, Use Cases, Entidades |
| `:data` | Repositórios, APIs, Banco de Dados |
| `:jitsi-wrapper` | Integração com Jitsi Meet SDK |
| `:common-ui` | Componentes reutilizáveis |

---

## 🛠️ Tecnologias Utilizadas

### Linguagem e Framework

- **Kotlin 1.9.0** - Linguagem principal
- **Android SDK 34** - Plataforma
- **Jetpack Compose 1.5.4** - Framework de UI moderno

### Comunicação e Dados

- **Retrofit 2.9.0** - Cliente HTTP
- **OkHttp 3.11.0** - Gerenciamento de requisições
- **Gson 2.10.1** - Serialização JSON

### Transmissão de Vídeo

- **Jitsi Meet SDK** - Plataforma de conferência
- **WebRTC** - Protocolo de comunicação
- **Feature Flags** - Customização de UI

### Arquitetura

- **Clean Architecture** - Separação de responsabilidades
- **MVVM** - Gerenciamento de estado
- **Hilt** - Injeção de dependência
- **Coroutines** - Programação assíncrona

---

## ✨ Funcionalidades

### ✅ Implementadas

- ✓ Integração com Jitsi Meet SDK
- ✓ Interface customizada com Compose
- ✓ Chat em tempo real
- ✓ Controle de áudio/vídeo
- ✓ Múltiplos participantes
- ✓ Feature flags customizáveis
- ✓ Clean Architecture

### 🚀 Em Desenvolvimento

- 📦 Gerenciamento de produtos
- 🛒 Carrinho de compras
- 💳 Sistema de pagamento
- ⭐ Reações com emojis
- 📊 Analytics de transmissão

### 📋 Planejado

- 🔔 Notificações push
- 💾 Persistência local (Room)
- 🌐 Suporte multilíngue
- 🧪 Testes automatizados
- 🔐 Integração com backend

---

## 🔒 Segurança & Privacidade

- ✓ Permissões mínimas solicitadas
- ✓ HTTPS obrigatório
- ✓ Proguard ativado (release)
- ✓ Sem rastreamento de dados pessoais
- ✓ Conformidade com LGPD

---

## 📊 Requisitos do Sistema

| Requisito | Especificação |
|-----------|---------------|
| Android | 7.0+ (API 24) |
| RAM | 2GB mínimo, 4GB recomendado |
| Câmera | Obrigatória |
| Microfone | Obrigatório |
| Internet | Conexão de banda larga |
| Permissões | Câmera, Microfone, Internet |

---

## 🆘 Troubleshooting

### Câmera não funciona

1. Vá para Configurações → Aplicativos → Live Commerce
2. Toque em Permissões
3. Habilite Câmera e Microfone
4. Reinicie o app

### Conexão com Jitsi falha

1. Verifique sua conexão de internet
2. Tente usar um nome de sala diferente
3. Reinicie o aplicativo
4. Se persistir, abra uma issue no GitHub

### Emulador muito lento

1. Aumente a RAM do AVD para 4GB+
2. Ative "Use Host GPU" nas opções
3. Use um dispositivo físico para testes

---

## 🤝 Contribuindo

Contribuições são bem-vindas! Veja [CONTRIBUTING.md](CONTRIBUTING.md) para detalhes.

### Como Contribuir

1. Fork o repositório
2. Crie uma branch (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

---

## 📞 Suporte & Contato

- **Issues:** https://github.com/LRCC-dev/live-commerce-app/issues
- **Discussões:** https://github.com/LRCC-dev/live-commerce-app/discussions
- **Email:** dev@livecommerce.app

---

## 📄 Licença

Este projeto está licenciado sob a MIT License - veja o arquivo [LICENSE](LICENSE) para detalhes.

---

## 👨‍💻 Desenvolvido por

**Manus AI** - Desenvolvedor Sênior Android  
Especialista em Kotlin, Clean Architecture e Integração de SDKs

---

## 🙏 Agradecimentos

- **Jitsi Meet** - Plataforma de vídeo conferência
- **Jetpack Compose** - Framework de UI Android
- **Android Community** - Comunidade Android

---

## 📝 Notas

> Se este projeto foi útil, considere dar uma ⭐ no GitHub!

**Versão:** 1.0.0  
**Status:** Em Desenvolvimento  
**Última Atualização:** Maio 2026
